// application.js
//= require scroll
//= require jquery.validate
//= require jquery.jcarousel-core.min
//= require jquery.jcarousel-pagination.min
//= require jquery.jcarousel-autoscroll.min
//= require jquery.mobile.custom.min
//= require effects
//= require main_menu
//= require switch_background
//= require schedule
//= require sponsors
//= require speakers_mobile
//= require about_carousel
