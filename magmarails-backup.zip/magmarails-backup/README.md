MagmaConf 2014
==============

MagmaConf is an annual Web Development Conference happening June 4, 5 & 6 2014 in the coastline city Manzanillo, Colima, Mexico.
